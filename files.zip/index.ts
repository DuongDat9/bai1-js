import express, { Request, Response } from "express";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// =====================
// Middleware
// =====================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// =====================
// MongoDB Connection
// =====================
const MONGO_URI = process.env.MONGO_URI || "mongodb://localhost:27017/node-app-db";

mongoose
  .connect(MONGO_URI)
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch((err) => console.log("⚠️  MongoDB not connected (running without DB):", err.message));

// =====================
// Mongoose Schema & Model
// =====================
interface IUser {
  name: string;
  email: string;
  createdAt: Date;
}

const userSchema = new mongoose.Schema<IUser>({
  name: { type: String, required: true },
  email: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
});

const User = mongoose.model<IUser>("User", userSchema);

// =====================
// In-memory store (fallback nếu không có MongoDB)
// =====================
let inMemoryUsers: Array<{ id: number; name: string; email: string; createdAt: string }> = [];
let nextId = 1;

// =====================
// GET /  — trang chào
// =====================
app.get("/", (req: Request, res: Response) => {
  res.json({
    message: "🚀 Server is running!",
    endpoints: {
      GET_all_users: "GET /myGetRequest",
      POST_create_user: "POST /myPostRequest",
    },
  });
});

// =====================
// GET /myGetRequest — lấy danh sách users
// =====================
app.get("/myGetRequest", async (req: Request, res: Response) => {
  try {
    // Thử lấy từ MongoDB trước
    if (mongoose.connection.readyState === 1) {
      const users = await User.find().sort({ createdAt: -1 });
      return res.status(200).json({
        success: true,
        source: "MongoDB",
        count: users.length,
        data: users,
      });
    }

    // Fallback: in-memory
    return res.status(200).json({
      success: true,
      source: "in-memory",
      count: inMemoryUsers.length,
      data: inMemoryUsers,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: String(error),
    });
  }
});

// =====================
// POST /myPostRequest — tạo user mới
// =====================
app.post("/myPostRequest", async (req: Request, res: Response) => {
  const { name, email } = req.body;

  // Validate input
  if (!name || !email) {
    return res.status(400).json({
      success: false,
      message: "Vui lòng cung cấp name và email",
    });
  }

  try {
    // Thử lưu vào MongoDB
    if (mongoose.connection.readyState === 1) {
      const newUser = new User({ name, email });
      const saved = await newUser.save();
      return res.status(201).json({
        success: true,
        message: "✅ User created successfully (MongoDB)",
        data: saved,
      });
    }

    // Fallback: lưu vào in-memory
    const newUser = {
      id: nextId++,
      name,
      email,
      createdAt: new Date().toISOString(),
    };
    inMemoryUsers.push(newUser);

    return res.status(201).json({
      success: true,
      message: "✅ User created successfully (in-memory)",
      data: newUser,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: String(error),
    });
  }
});

// =====================
// Start Server
// =====================
app.listen(PORT, () => {
  console.log(`🚀 Server is listening on port ${PORT}`);
  console.log(`📡 GET  http://localhost:${PORT}/myGetRequest`);
  console.log(`📡 POST http://localhost:${PORT}/myPostRequest`);
});

export default app;
